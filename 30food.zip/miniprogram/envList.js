const envList = [{"envId":"cloud1-1g5rpv5n6177b545","alias":"cloud1"}]
const isMac = true
module.exports = {
    envList,
    isMac
}